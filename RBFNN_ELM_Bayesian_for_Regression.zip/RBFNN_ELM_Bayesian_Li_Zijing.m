%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
%           Fuzzy Extreme Learning Machine & Bayesian Learning
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
% good tutorial: https://zjost.github.io/bayesian-linear-regression/
% This code was updated for Li Zijin
tic
clear all;
close all;
filename = '/Users/Gooolden/Desktop/project/RBFNN_ELM_Bayesian_for_Regression/data_del_remove.xlsx';
raw_data = xlsread(filename);
% Normalisation Stage
%[ raw_data ] = normalisation_1( M(:,1:end), 2 );
xinput = raw_data(:,1:end-4);
xlabel = raw_data(:,end);%M(:,end);Voc=end-2
dimension = size(xinput,2);
% Normalize the data
[ xinput ] = normalisation_1( xinput, 2 );% option == 1 normalise to [-1,1],
%% Rearranging data
samples4training = round(0.8*size(xinput,1));
samples4testing = size(xinput,1) - (samples4training);
px = randperm(size(xinput,1));%1:size(xinput,1);%randperm(size(xinput,1));
% Variables for training
data4training = zeros(samples4training,dimension);
label4training = zeros(samples4training,1);
% Variables for testing
data4testing = zeros(samples4testing,dimension);
label4testing = zeros(samples4testing,1);
%..........................................................................
number_classes = 1;
%..........................................................................
%% Data 4 Training
%..........................................................................
index = 0;
   for k = 1:samples4training
         index = index + 1;
         data4training(index,:) = xinput(px(k),1:end);
         label4training(index,1) = xlabel(px(k),1);
   end
%..........................................................................
%      Loading checking
%..........................................................................
%                          Loading checking
%..........................................................................
%                                                   Loading checking
%..........................................................................
index = 0;
%..........................................................................
    for k = samples4training + 1:samples4training + samples4testing 
        index = index + 1;
                data4testing(index,:) = xinput(px(k),1:end);
                label4testing(index,1) = xlabel(px(k),1);
    end
% Loading testing
index = 0;
%..........................................................................
%..........................................................................
%% Training & Clustering(Granulation)
%..........................................................................
%..........................................................................
%%%%%%%%%%% Macro definition
REGRESSION=0;
CLASSIFIER=1;
Elm_Type = 0;
%..........................................................................
%..........................................................................
%% Training & Checking data Arrangement
%                                      Training & Checking data Arrangement
%..........................................................................
%..........................................................................
Testcode = 0;
TrainDataSize = 0;
%..........................................................................
%..........................................................................
%%
    %%%%%%%%%%% Load training dataset
    P = data4training';%loadMNISTImages('mnist/train-images.idx3-ubyte');
    T = label4training;%loadMNISTLabels('mnist/train-labels.idx1-ubyte');
    T = T';
%%
    if TrainDataSize ~= 0
        rand_sequence=randperm(TrainDataSize);
        temp_P=P';
        temp_T=T';
        clear P;
        clear T;
        P=temp_P(rand_sequence, :)';
        T=temp_T(rand_sequence, :)';
        clear temp_P;
        clear temp_T;
    end 

    %%%%%%%%%%% Load testing dataset
    TV.T = label4testing;%loadMNISTLabels('mnist/t10k-labels.idx1-ubyte');
    TV.T = TV.T';                                   %   Release raw testing data array
    TV.P=data4testing';


    NumberofTrainingData = size(P,2);
    NumberofTestingData = size(TV.T,2);
    NumberofInputNeurons = size(P,1);


if Elm_Type~=REGRESSION
    %%%%%%%%%%%% Preprocessing the data of regression
    sorted_target=sort(cat(2,T,TV.T),2);
    label=zeros(1,1);                               %   Find and save in 'label' class label from training and testing data sets
    label(1,1)=sorted_target(1,1);
    j=1;
    for i = 2:(NumberofTrainingData+NumberofTestingData)
        if sorted_target(1,i) ~= label(1,j)
            j=j+1;
            label(1,j) = sorted_target(1,i);
        end
    end
    number_class=j;
    NumberofOutputNeurons=number_class;

    %%%%%%%%%% Processing the targets of training
    temp_T=zeros(NumberofOutputNeurons, NumberofTrainingData);
    for i = 1:NumberofTrainingData
        for j = 1:number_class
            if label(1,j) == T(1,i)
                break; 
            end
        end
        temp_T(j,i)=1;
    end
    T=temp_T*2-1;

    %%%%%%%%%% Processing the targets of testing
    temp_TV_T=zeros(NumberofOutputNeurons, NumberofTestingData);
    for i = 1:NumberofTestingData
        for j = 1:number_class
            if label(1,j) == TV.T(1,i)
                break; 
            end
        end
        temp_TV_T(j,i)=1;
    end
    TV.T=temp_TV_T*2-1;


end
%++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
NumberofHiddenNeurons = 100;
data4training = data4training';
data4testing = data4testing';
%..........................................................................
%%%%%%%%%%% Calculate Matrix 'H' for
%--------------------------------------------------------------------------
epsilon =10;
stop = 1;
Alpha = 0.5;
gamma = 0.1;
sigma = 1.5;
iter = 0;
final = 100;
norma = zeros(final,1);
%..........................................................................
while iter < final 
     iter = iter + 1;
     %.....................................................................
     % Creating RBF Gaussian Parameters where No_clusters < Kernels
     min_s = 0.8;% range of standard error. restrict the shape of distrubution
     max_s = 1;
     mk_min = 0;% range of mean value. restrict the location of the distribution
     mk_max = 1;
    
     C = 100;% C is the penalty constant
     no_dimensions = size(P,1); %  -------> number of dimensions(insertado)
     s = (max_s-min_s).*rand( NumberofHiddenNeurons,1 ) + min_s; % Creating 
     %Sigma = diag(s);  
     mk = (mk_max-(mk_min)).*rand( NumberofHiddenNeurons,no_dimensions ) + (mk_min); % Creating 
     fi = zeros(size(P,2), NumberofHiddenNeurons);  
     for j =1:NumberofHiddenNeurons
       % Subtract the mean from every data point.
       meanDiff = bsxfun(@minus, P', mk(j,:));
       % Calculate the multivariate gaussian.
       fi(:,j) = exp(-1/2 * sum((meanDiff * inv( s(j)^2) .* meanDiff), 2));
      % [j j]
     end
     % Membership Functions and Firing strengths
     W = bsxfun(@rdivide, fi, sum(fi, 2)); 
     H = W';
     
     
     OutputWeight = (eye(size(H,1))/C + H * H') \ ( H * T'); 
    %InputDataLayer = H;
     %.....................................................................
     % Bayesian's parameter estimation
     Beta_1 = (1/(2*sigma^2));
     S = inv( Beta_1*(H*H') + Alpha*eye(size(H,1)) );
     w = Beta_1*S*H*T';
     gamma = NumberofHiddenNeurons - Alpha*trace(S);
     d_aux = w'*w;
     Alpha = gamma/d_aux;
     d_aux = H'*w;
     aux = norm(T' - d_aux);
     aux = aux*aux;
     Beta_1 = aux/(size(T,2) - gamma);
     % New Sigma
     %sigma_new = sigma^2 +
     %.....................................................................
     Y=(H' * w)';
     %%%%%%%%%%% Calculate the training accuracy                             %   Y: the actual output of the training data
     if Elm_Type == REGRESSION
       TrainingAccuracy=sqrt(mse(T - Y));               %   Calculate training accuracy (RMSE) for regression case
       % Mean Average Error
       Maerror = mae(T - Y);
        R2_train = rsquare(label4training,Y'); 
    
     end
     clear H;
     %.....................................................................
     norma(iter,1) = norm(w); 
     %.....................................................................
     [Beta_1 gamma Alpha norma(iter,1) iter Maerror]
     if iter > 1 
        if (norm(norma(iter,1) - norm(iter-1,1))) < 3
            break;
        end
     end
     %pause;
end
toc
%..........................................................................
 TrainingTime=toc;
[TrainingAccuracy]

%..........................................................................
%   Testing  Stage
%..........................................................................
fi = zeros(size(TV.P,2), NumberofHiddenNeurons);  
     for j =1:NumberofHiddenNeurons
       % Subtract the mean from every data point.
       meanDiff = bsxfun(@minus, TV.P', mk(j,:));
       % Calculate the multivariate gaussian.
       fi(:,j) = exp(-1/2 * sum((meanDiff * inv( s(j)^2) .* meanDiff), 2));
      % [j j]
     end
     % Membership Functions and Firing strengths
     W = bsxfun(@rdivide, fi, sum(fi, 2)); 
     Ht = W';
     TY=Ht' * w ;
 if Elm_Type == REGRESSION
    %%%%%%%%%%%%%% Calculate RMSE in the case of REGRESSION

   % Limiter to avoid any value to below zero
  for i = 1:size(TY,2)
     if TY(1,i) < 0
         TY(1,i) = 0;
     end
  end
    TestingAccuracy=sqrt(mse(TV.T - TY')) 
    R2_test = rsquare(label4testing,TY)
 end
  [TrainingAccuracy R2_train TestingAccuracy R2_test]
 
%% regression figure  
% plot(label4testing,TY,'o');
% hold on
% % plotline
% x = 0:25
% y = x
% plot(x,y,'linewidth',1,'MarkerEdgeColor','r')
%    plot(label4testing,label4testing);
% %..........................................................................
%% ..........................................................................
%%% 3D figure
%  varX = 5;
%  varY = 8;
%  res = 50;
% [ X1, Y1, Z1 ] = Optimal_region_surface( varX, varY, data4training, res, NumberofHiddenNeurons, par(), OutputWeight, 'radbas' );
% % Plotting Surface
% X1_new = zeros(res,res);
% Y1_new = zeros(res,res);
% This transforms normalized data to original data 
%for col = 1:res
%     for row=1:res
%         X1_new(row,col) = min_values(1,varX) + ( X1(row,col)*( max_values(1,varX) - min_values(1,varX) ) );
%         Y1_new(row,col) = min_values(1,varY) + ( Y1(row,col)*( max_values(1,varY) - min_values(1,varY) ) );
%     end
% end
% surf(X1_new,Y1_new,Z1,'FaceAlpha',0.5);
% colorbar;

%% figure for 3 different dimension
% figure
% x = data4testing(6,:);
% y = data4testing(7,:);
% z = data4testing(9,:);
% pce = TY';
% scatter3(x,y,z,40,pce,'filled');
% xlabel('ES')
% ylabel('CT')
% zlabel('ST')
% cb = colorbar;                                     % create and label the colorbar
% cb.Label.String = 'PCE (%)';

% ax = gca;
% ax.XDir = 'reverse';
% view(-31,14);
% hold on 
% xtemp=linspace(min(x),max(x),100);
% ytemp=linspace(min(y),max(y),100);
% [X,Y]=meshgrid(xtemp,ytemp);
% Z=griddata(x,y,z,X,Y,'v4');
% mesh(X,Y,Z)

